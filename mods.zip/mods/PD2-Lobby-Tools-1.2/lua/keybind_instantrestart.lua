local Mod = _G.LobbyToolsMod

Mod:request_action(Mod.actions.instant_restart)