# Lobby Tools
A Payday 2 BLT-Mod which adds the following hotkeys:
- Instant Restart
- Force Ready (start game even if players are not ready)

All Hotkeys will work clientside, if the Host also have this mod and is your friend on Steam.

Inspired by:
- [Useful Force Ready](http://www.nexusmods.com/payday2/mods/71/?) by kiraver.
