# Payday 2 BLT
An open source Lua hook for Payday 2, designed and created for ease of use for both players and modders.  
This repository is for the Lua base that controls and loads mods into Payday 2, and the options and save files associated with the BLT. The DLL hook code can be found in it's own [repository](https://github.com/JamesWilko/Payday-2-BLT).

This is the developer repository, and should only be used if you know what you're doing. If you don't, visit the website at [PaydayMods.com](http://paydaymods.com/) to get an up-to-date drag-drop install.  

## Download
Visit [PaydayMods.com](http://paydaymods.com/) to get the latest stable download.  
