ExampleClass = ExampleClass or class()

function ExampleClass:init()

end
